import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
Container getcontainer(String a, String b) {
  return Container(
    child: Row(
      children: [
        Padding(
          padding: const EdgeInsets.all(5.0),
          child:
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(
              a,
              style: GoogleFonts.abel(fontSize: 20),
            ),
            Text(
              b,
              style: const TextStyle(fontSize: 10),
            ),
            const Padding(
              padding: EdgeInsets.fromLTRB(30, 0, 0, 10),
              child: Text(
                '2D',
                style: TextStyle(fontSize: 10),
              ),
            )
          ]),
        ),
        const SizedBox(
          width: 150,
        ),
        RaisedButton(
          onPressed: () {},
          child: const Text('BOOK'),
          color: Colors.red,
        )
      ],
    ),
  );
}