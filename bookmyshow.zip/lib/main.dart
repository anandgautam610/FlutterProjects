import 'book.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(const MaterialApp(
    home: MyShow(),
    debugShowCheckedModeBanner: false,
  ));
}