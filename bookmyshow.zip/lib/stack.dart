import 'package:flutter/material.dart';
Stack getstack(String c) {
  return Stack(
    children: [
      Card(
        child: Image(image: NetworkImage(c)),
        margin: const EdgeInsets.only(right: 5, left: 5, top: 10),
      ),
      Positioned(
        top: 30,
        right: 100,
        child: Container(
          width: 20,
          height: 20,
          color: Colors.transparent,
          child: Column(
            children: [
              Expanded(
                flex: 1,
                child: Padding(
                  padding: const EdgeInsets.only(right: 30),
                  child: Row(
                    children: const [Icon(Icons.heart_broken), Text('87%')],
                  ),
                ),
              ),
              const Expanded(
                flex: 1,
                child: Text(
                  '7,809 votes',
                  style: TextStyle(fontSize: 10),
                ),
              )
            ],
          ),
        ),
      ),
    ],
  );
}