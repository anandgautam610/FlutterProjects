import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
Container getbar() {
  return Container(
    height: 50,
    margin: const EdgeInsets.only(top: 5),
    decoration: BoxDecoration(color: Colors.grey.shade400),
    child: Row(
      children: [
        const SizedBox(
          width: 20,
        ),
        const Padding(
          padding: EdgeInsets.fromLTRB(20, 0, 0, 0),
          child: Icon(Icons.autofps_select_rounded),
        ),
        const SizedBox(
          width: 10,
        ),
        Text('All Languages', style: GoogleFonts.lato()),
        const SizedBox(
          width: 60,
        ),
        const Divider(
          thickness: 2,
          height: 10,
          color: Colors.white,
        ),
        const SizedBox(
          width: 20,
        ),
        const Padding(
          padding: EdgeInsets.fromLTRB(30, 0, 0, 0),
          child: Icon(Icons.chair),
        ),
        const SizedBox(
          width: 10,
        ),
        Text('Cinemas', style: GoogleFonts.lato()),
      ],
    ),
  );
}