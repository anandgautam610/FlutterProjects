import 'movies.dart';
import 'stack.dart';
import 'package:flutter/material.dart';
import 'bar.dart';
class MyShow extends StatelessWidget {
  const MyShow({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(70),
        child: AppBar(
          backgroundColor: Colors.grey.shade800,
          title: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              const Padding(
                padding: EdgeInsets.fromLTRB(0, 8, 0, 0),
                child: Icon(Icons.menu),
              ),
              const SizedBox(
                width: 20,
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(30, 8, 0, 0),
                child: RaisedButton(
                  child: const Text('Now Showing'),
                  onPressed: () {},
                  color: Colors.red,
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(0, 8, 0, 0),
                child: RaisedButton(
                  onPressed: () {},
                  child: const Text('Coming Soon'),
                  color: Colors.grey.shade400,
                ),
              ),
              const SizedBox(
                width: 25,
              ),
              const Padding(
                padding: EdgeInsets.fromLTRB(20, 8, 0, 0),
                child: Icon(Icons.location_on),
              ),
            ],
          ),
          elevation: 10,
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.fromLTRB(5, 0, 5, 0),
        child: Column(
          children: [
            getbar(),
            getstack(
                'https://prakashgowda.files.wordpress.com/2017/05/hindi-medium-movie-poster.jpg'),
            getcontainer('Hindi Medium', 'Hindi'),
            Padding(
              padding: const EdgeInsets.fromLTRB(0, 15, 0, 0),
              child: getstack(
                  'https://data1.ibtimes.co.in/en/full/642100/half-girlfriend-poster.jpg'),
            ),
            getcontainer('Half Girlfriend', 'Hindi'),
            Padding(
              padding: const EdgeInsets.fromLTRB(0, 45, 0, 0),
              child: BottomNavigationBar(
                type: BottomNavigationBarType.fixed,
        backgroundColor: Colors.grey.shade800,
  //       selectedItemColor: Colors.greenAccent,
   unselectedItemColor: Colors.grey,
                items: const <BottomNavigationBarItem>[
                  BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
                  BottomNavigationBarItem(
                      icon: Icon(Icons.search), label: 'Search'),
                  BottomNavigationBarItem(
                      icon: Icon(Icons.headset_rounded), label: 'Head'),
                  BottomNavigationBarItem(
                    icon: Icon(Icons.android),
                    label: 'Android',
                  ),
                ],
                fixedColor: Colors.blue,
              ),
            )
          ],
        ),
      ),
    );
  }
}