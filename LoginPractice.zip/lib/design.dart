import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class MyApp extends StatelessWidget{
  @override
  Container _getContainer(String e) {
    return Container(
      height: 180,
      width: 180,
      child: Card(
        elevation: 10,
        margin: EdgeInsets.only(left: 15, top: 15),
        child: Image(image: NetworkImage(e)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        // shadowColor: Color.fromARGB(2, 148, 191, 69),
        title: Center(child: Text("Categories")),
  leading: Padding(
    padding: const EdgeInsets.only(right: 1),
    child: GestureDetector(
      onTap: () {
        Navigator.of(context).pop();
      },
      child: Icon(
        Icons.arrow_back,
        
      ),
    ),
  ),
        automaticallyImplyLeading: false,
        // centerTitle: true,
        foregroundColor: Colors.white,
        backgroundColor: Color.fromARGB(255, 62, 40, 99),
        actions: [
          // Padding(
          //     padding: EdgeInsets.only(right: 290),
          //     child: Icon(Icons.arrow_back)),
           Padding(
              padding: EdgeInsets.only(right: 10), child: Icon(Icons.search)),
        ],
      ),
      body: Column(
        children: [
          Row(children: [
            _getContainer(
                'https://media.npr.org/assets/news/2010/04/26/groceries_custom-80dfd344761fbd31d923a1d02ce81e3c6632c343-s300-c85.webp'),
            _getContainer(
                'https://www.pngfind.com/pngs/m/203-2037150_groceries-png-free-download-groceries-png-transparent-png.png'),
          ]),
          Row(children: [
            _getContainer(
                'https://imgcdn.floweraura.com/chocolates-n-chocolates-9993080co-080218.jpg'),
            _getContainer(
                'https://www.verywellhealth.com/thmb/g4bdIIxlfbD1q7q9J5mNLZcjbu0=/614x0/filters:no_upscale():max_bytes(150000):strip_icc():format(webp)/uncover-hidden-egg-ingredients-1324275-primary-recirc-3cf777cca7044ee1992cc0a27d6449fa.jpg')
          ]),
          Row(
            children: [
              _getContainer(
                  'https://www.bigbasket.com/media/uploads/p/l/40092247_2-britannia-bread-healthy-slice.jpg'),
              _getContainer(
                  'https://images-eu.ssl-images-amazon.com/images/I/41qGcKAQmbL._SX300_SY300_QL70_FMwebp_.jpg')
            ],
          ),
          
        ],
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.add),
        onPressed: () {},
      ),
    );
}
}