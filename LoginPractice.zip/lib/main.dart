import 'package:flutter/material.dart';
import 'design.dart';
import 'front.dart';

void main() {
  runApp(MaterialApp(
    home: 
    // MyApp()
    Front(),
    routes: {
      'design':((context) => MyApp())
    },
    ));
}