import 'package:flutter/material.dart';

class Front extends StatelessWidget {
  const Front({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromARGB(255, 222, 213, 213),
      appBar: AppBar(
        title: Text("Login Page"),
        backgroundColor: Color.fromARGB(255, 16, 15, 15),
      ),
      body: Stack(children: [
        Image.network('https://cdn.mos.cms.futurecdn.net/6bxva8DmZvNj8kaVrQZZMP.jpg'),
        SingleChildScrollView(
          child: Container(
            padding: EdgeInsets.only(top: MediaQuery.of(context).size.height*0.3,
            left: 35,
            right: 35),
            child: Column(
              children: [
                _textfield(pass: 'Email'),
                SizedBox(height: 30,),
                _textfield(pass: 'password'),
                SizedBox(height: 20,),
                FlatButton(onPressed: (){Navigator.pushNamed(context, 'design');}, child: Text("Submit",style: TextStyle(
                  fontSize: 27,
                  fontWeight: FontWeight.bold
                ),))
              ],
            ),
          ),
        )
      ]),
    );
  }

  TextField _textfield({required String pass}) {
    return TextField(
              decoration: InputDecoration(
                hintText: pass,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10)
                )
              ),
            );
  }
}