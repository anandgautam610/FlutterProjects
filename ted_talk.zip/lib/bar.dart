import 'package:flutter/material.dart';

Container getBar(){
  return Container(
    height: 50,
    margin: EdgeInsets.only(top:5),
    decoration: BoxDecoration(color: Color.fromARGB(255, 255, 255, 255)),
    child: Row(
      children: [
        SizedBox(
          width: 20,
        ),
        Padding(
          padding: const EdgeInsets.only(left: 20),
          child: Text("Newest",style: TextStyle(color: Colors.red,fontSize: 20),),
        ),
        Padding(
          padding: const EdgeInsets.only(left: 40),
          child: Text("Trending",style: TextStyle(fontSize: 20),),
        ),
         Padding(
          padding: const EdgeInsets.only(left: 40),
          child: Text("Most Viewed",style: TextStyle(fontSize: 20),),
        ),
      ],
    ),
  );
}