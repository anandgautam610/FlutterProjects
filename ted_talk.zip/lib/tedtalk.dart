import 'package:flutter/material.dart';
import 'package:ted_talk/bar.dart';
import 'package:ted_talk/headline.dart';
import 'package:ted_talk/newest.dart';

class TedTalk extends StatelessWidget {
  const TedTalk({ Key? key }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
       appBar:AppBar( 
        backgroundColor: Color.fromARGB(255, 45, 30, 30),
        title: Text("TED",style: TextStyle(color: Colors.red,fontSize: 35)),
        actions: [Padding(
          padding: const EdgeInsets.fromLTRB(0, 0, 20, 0),
          child: Icon(Icons.cast),
        )],
      ),  
      body: SingleChildScrollView(
        child: Column(children: [
          getBar(),
          getNewest('https://i.insider.com/559c41ac6bb3f7941c5ff6d9?width=1136&format=jpeg'),
          getHeadline("The genius behind some of the world's most \n famous buildings", "Steve Jobs"),
          getNewest("https://static01.nyt.com/images/2019/12/03/business/03musk/03musk-superJumbo.jpg"),
          getHeadline("A map that shows you the shorest paths to \n happiness", "Elon Musk"),
        ]
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        backgroundColor: Color.fromARGB(255, 45, 30, 30),
        selectedItemColor: Colors.greenAccent,
  unselectedItemColor: Colors.grey,
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.home,color: Colors.black),
            label: 'Talk',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.compass_calibration,color: Colors.black),
            label: 'Discover',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.bubble_chart,color: Colors.black),
            label: 'Surprise Me',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person,color: Colors.black,),
            label: 'My TED',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.search,color: Colors.black),
            label: 'Search',
          ),
        ],
        // selectedItemColor: Colors.blue,
      )
    );
  }
}