import 'package:flutter/material.dart';
import 'package:ted_talk/screen/widget/title.dart';

class BMI extends StatelessWidget {
  const BMI({ Key? key }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Column(children: [
        TitleWidget()
      ],)
    );
  }
}