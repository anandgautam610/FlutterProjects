import 'package:flutter/material.dart';

class TitleWidget extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
   return Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text('BMI CALCULATOR',style: TextStyle(fontSize: 40,color: Colors.white),)
          ],
        );
  }
}