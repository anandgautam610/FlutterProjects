import 'package:flutter/material.dart';

import 'tedtalk.dart';

void main() {
  runApp( MaterialApp(
    home: TedTalk(),
    debugShowCheckedModeBanner: false,
  ) );
}