import 'package:flutter/material.dart';

Stack getNewest(String c){
  return Stack(
    children: [
      Card(
        child: Image.network(c),
        margin: EdgeInsets.only(right: 5,left:5,top: 10 ),
      )
    ],
  );
}