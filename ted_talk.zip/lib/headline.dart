import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

Container getHeadline(String a, String b){
  return Container(
    child: Row(
      children: [
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,children: [
            Padding(
              padding: const EdgeInsets.only(left: 8,top: 5),
              child: Text(a,style: TextStyle(fontSize: 20),),
            ),
            Padding(
              padding: const EdgeInsets.only(left: 8,top: 5),
              child: Text(b,style: GoogleFonts.abel(fontSize: 15)),
            )
          ],
        )
      ],
    ),
  );
}