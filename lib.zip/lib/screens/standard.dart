import 'package:flutter/material.dart';

class MyApp extends StatefulWidget {
  @override
  State<MyApp> createState() => _MyAppState();

}

class _MyAppState extends State<MyApp> {
  int currentindex =0;
   String result ="";
  TextEditingController heightController = TextEditingController();
  TextEditingController weightController = TextEditingController();
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromARGB(221, 96, 90, 90),
      appBar: AppBar(
        backgroundColor: Color.fromARGB(255, 193, 157, 52),
         title: Text("BMI Calculator",style: TextStyle(fontSize: 25),),), 
    body: 
    SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                SizedBox(height:150),
                radioButton("Male", Color.fromARGB(255, 158, 134, 14), 0),
                radioButton("Female", Colors.pink, 1)
              ],
            ),
            SizedBox(
              height: 10,
            ),
            Text("Your Height in cm:", style: TextStyle(
              fontSize: 20,
              // color: Colors.white,
              fontWeight: FontWeight.bold,
            ),
            ),
            SizedBox(
              height: 10,
            ),
            TextField(
              keyboardType: TextInputType.number,
              controller: heightController,
              decoration: InputDecoration(
                hintText: "Your height in cm:",
                filled: true,
                fillColor: Colors.grey[200],
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8.0),
                borderSide: BorderSide.none)
              ),
            ),
          SizedBox(
            height: 40,
          ),
          Text("Your Weight in kg:", style: TextStyle(
              fontSize: 20,
              // color: Colors.white,
              fontWeight: FontWeight.bold,
            ),
            ),
            SizedBox(
              height: 10,
            ),
            TextField(
              keyboardType: TextInputType.number,
              controller: weightController,
              decoration: InputDecoration(
                hintText: "Your Weight in kg:",
                filled: true,
                fillColor: Colors.grey[200],
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8.0),
                borderSide: BorderSide.none)
              ),
            ),
            SizedBox(
              height: 50,
            ),
            Container(
              width: double.infinity,
              height: 50,
              child: FlatButton(
                onPressed: (){
                    double height = double.parse(heightController.value.text);
                    double weight = double.parse(weightController.value.text);
                    calculateBMI(height, weight);
                },
                color: Color.fromARGB(255, 204, 142, 35),
                child: Text("Calculate",style: TextStyle(
                  color: Colors.white,
                ),),
              ),
            ),
            SizedBox(height: 40,),
            Container(
              width: double.infinity,
              child: Text("Your BMI is :",
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),),
            ),
            Container(
              width: double.infinity,
              child: Text("$result",
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),),
            )
          ],
        ),
      ),
    )
    );
  }

  void calculateBMI(double height, double weight){
    double finalresult = weight / (height*height/10000);
    String bmi = finalresult.toStringAsFixed(2);
    setState(() {
      result = bmi;
    });
  }

  void changeIndex(int index){
    setState(() {
      currentindex = index;
    });
  }


Widget radioButton(String value, Color color,int index){
  return Expanded(
    child: Container(
      margin: EdgeInsets.symmetric(horizontal: 12),
      height: 65,

      child: FlatButton(
        color: currentindex ==index ? color: Colors.grey[200],
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8.0)),
    onPressed: (){
      changeIndex(index);
    },
        child: Text(value,style: TextStyle(
          color: currentindex == index ? Colors.white :color,
          fontSize: 18,
          fontWeight: FontWeight.bold,

        ),)),
    ));
}

}