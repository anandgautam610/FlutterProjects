import 'package:flutter/material.dart';
import 'package:emi_calculator/widget/field.dart';
import 'dart:math';
class MyEmi extends StatefulWidget {
  const MyEmi({ Key? key }) : super(key: key);

  @override
  State<MyEmi> createState() => _MyEmiState();
}

class _MyEmiState extends State<MyEmi> {
  String result ="";
  TextEditingController amount = TextEditingController();
   TextEditingController rate = TextEditingController();
    TextEditingController timeperiod = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color.fromARGB(255, 155, 121, 17),
        title: Text("EMI Calculator",style: TextStyle(
          fontSize: 25,
          fontWeight: FontWeight.bold,
        ),
        ),
      ),
      body: SafeArea(
        child:
        SingleChildScrollView(
        child: Column(
          children: [
            Field(
                label: 'Home Loan Amount',
                iconData: Icons.currency_exchange,
                range: 200,
                tc: amount,),
            Field(label: 'Interest Rate', 
                iconData: Icons.percent, 
                range: 20,
                tc:rate ),
            Field(
                label: 'Loan Tenure',
                iconData: Icons.calendar_view_day,
                range: 30,
                tc: timeperiod,),

                SizedBox(height: 20,),
                Text("Your EMI",style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold,)),
                Container(
              width: double.infinity,
              child: Text("$result",
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),),
            ),
            SizedBox(height: 30,),

            Container(
              width: double.infinity,
              height: 50,
              child: FlatButton(
                onPressed: (){
                    double amount1 = double.parse(amount.value.text);
                    double rate1 = double.parse(rate.value.text);
                    double timeperiod1 = double.parse(timeperiod.value.text);
                    calculateEMI(amount1, rate1, timeperiod1);
                },
                color: Color.fromARGB(255, 204, 142, 35),
                child: Text("Calculate",style: TextStyle(
                  color: Colors.white,
                ),),
              ),
            ),
          ],
        ),
      ),
      ),

    );
  }

  void calculateEMI(double amount, double rate, double timeperiod){
    double r = (rate*0.01)/timeperiod;
    num pamount = pow((1+r), timeperiod);
    double? p_int = (pamount*amount*r)/(pamount-1);
    String pint = p_int.toStringAsFixed(2);
    setState(() {
      result = pint;
    });
  }
}