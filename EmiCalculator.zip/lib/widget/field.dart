import 'package:flutter/material.dart';

class Field extends StatelessWidget {
  String label;
  IconData iconData;
  double range;
  TextEditingController tc ;
  late double currentValue = 0.0;

  Field({required this.label, required this.iconData, required this.range, required this.tc});

  // TextEditingController amount = TextEditingController();
  // TextEditingController rate = TextEditingController();
  // TextEditingController timeperiod = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.all(10),
      child: Column(children: [
        Row(
          children: [
            Expanded(child: Text(label)),
            Expanded(
              flex: 2,
              child: TextField(
                controller: tc,
                decoration: InputDecoration(
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10)),
                    suffixIcon: Icon(iconData)),
              ),
            )
          ],
        ),
        Slider(
            value: currentValue,
            min: 0,
            max: range,
            onChanged: (double value) {})
      ]),
    );
  }
}
